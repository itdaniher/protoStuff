#include "USI_TWI_Master.h"
#include "PCA9635.h"
#include <avr/io.h>
#include <util/delay.h>
#include "globals.h"

void main(void){
	DDRB=(1<<DDB1);
        USI_TWI_Master_Initialise();
        unsigned char  messageBuf [MESSAGEBUF_SIZE] = {(ALLCALL_addr<<TWI_ADR_BITS)|(0<<TWI_READ_BIT), MODE1|0b100<<5, 0b10000001, 0b00110100,
                 MAX, MAX, MAX, MAX, MAX, MAX, MAX, MAX, MAX, MAX, MAX, MAX, MAX, MAX, MAX, MAX,
                 0x80, 0x00, 0xFF, 0xFF, 0x00, 0x00};
	PORTB=(0<<PB1);
        temp = 0x00;
        for (;;) {
        temp++;
        messageBuf[4] = temp%0xFF;
        messageBuf[5] = temp%0xFF;
        messageBuf[6] = temp%0xFF;
        messageBuf[7] = temp%0xFF;
        messageBuf[8] = temp%0xFF;
        messageBuf[9] = temp%0xFF;
        messageBuf[10] = temp%0xFF;
        messageBuf[11] = temp%0xFF;
        USI_TWI_Start_Read_Write(messageBuf, 26);
        _delay_ms(100);
        }
}
