//PB0 / SDA
//PB1 as input, low - sink current
//PB2 / SCL
//PB3 / ADC3 as input
//PB4 / PCINT4 as interrupt

#include "globals.h"
//include colorshift, MODE definitions, lots of random stuff
#include "PCA9635.h"
//include custom register definitions for the PCA9635
#include "USI_TWI_Master.h"
//I2C driver for the Attiny's USI hardware
/*	see http://www.instructables.com/id/I2C_Bus_for_ATtiny_and_ATmega/step3/I2C-Drivers/ for a really nice explaination of the various functions in USI_TWI_Master
 *	USI_TWI_Start_Read_Write: "So if 6 bytes are to be written, then the message size will be 8 (slave address + memory address + 6 bytes of data)."
 *	USI_TWI_Start_Random_Read: "The messageSize should be 2 plus the number of bytes to be read.
 *		If no errors occurred, the data will be in the buffer beginning at the second location."
 *	in short...
 * 	use USI_TWI_Start_Read_Write for single byte read/writes and multi-byte writes
 *	use USI_TWI_Start_Random_Read for multi-byte reads
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "blink.c"

void handleError( unsigned char errorMsg ){
//basic premise is to cause an externally visible indicator if i2c errors occur.
//this code toggles the output-enable pin at 5hz with a 50% duty cycle
}

void PCA9635_init(void){
	blink();
	_delay_ms(500);
	blink();
	messageBuf[0] = (ALLCALL_addr<<TWI_ADR_BITS)|(0<<TWI_READ_BIT);
//shift by one bit, append 0 for a write opperation
	messageBuf[1] = MODE1|0x80;
//MODE1 or'd with autoincrement-through-all registers
	messageBuf[2] = 0x81;
//value for MODE1
	messageBuf[3] = 0x0d;
//value for MODE2
//0b00001101;
	messageBuf[4] = 0x00;
//value for channel 1
	USI_TWI_Start_Read_Write(messageBuf, 5);
//write 5 bytes
	blink();
	_delay_ms(500);
	blink();
	_delay_ms(500);
}

int main( void ){
/* --BEGIN SETUP-- */
/*TWI/USI code*/
	USI_TWI_Master_Initialise();
/*digital pin code*/
	DDRB = (1 << DDB4);
	//PB4 as output
	PORTB = (0 << PB4);

	PCA9635_init();
/* --END SETUP-- */

	for (;;) {
		blink();
		messageBuf[0] = (ALLCALL_addr<<TWI_ADR_BITS)|(0<<TWI_READ_BIT);
		messageBuf[1] = PWM0;
		messageBuf[2] = MAX;
		USI_TWI_Start_Read_Write(messageBuf, 3);
		_delay_ms(100);
		messageBuf[0] = (ALLCALL_addr<<TWI_ADR_BITS)|(0<<TWI_READ_BIT);
		messageBuf[1] = PWM0;
		messageBuf[2] = MIN;
		USI_TWI_Start_Read_Write(messageBuf, 3);
	}
return 0;
}

