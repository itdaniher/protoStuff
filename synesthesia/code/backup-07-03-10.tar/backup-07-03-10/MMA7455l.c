void IntLatch(void)
{
IIC_ByteWrite(INTRST, 0x03);
IIC_ByteWrite(INTRST, 0x00);
}

