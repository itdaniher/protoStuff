#include "globals.h"
#include <avr/io.h>
#include <util/delay.h>

void blink( void )
{
    DDRB = (1 << DDB4);
    PORTB = (0 << PB4);
    _delay_ms(100);
    PORTB = (1 << PB4);
    _delay_ms(20);
    PORTB = (0 << PB4);
    _delay_ms(10);
    PORTB = (1 << PB4);
    _delay_ms(10);
    PORTB = (0 << PB4);
}

