/*****************************************************************************
*
* File              : HeaterControl.c
* Compiler          : gcc
* Date              : Sunday, 11/16/08		
* Updated by        : jkl
*
*                     Written for the ATtiny2313.
*
* 	This program controls a hot plate heater used for soldering. Pulse Width
* Regulation is the control method. Uses I2C routines to read two 8 bit switch 
* blocks. The settings will control pulse timing.
*
****************************************************************************/
#include <avr/interrupt.h>
#define F_CPU 1000000UL	      // Sets up the default speed for delay.h
#include <util/delay.h>
#include <avr/io.h>
#include "USI_TWI_Master.h"

#define SLAVE1_ADDR  0x38	// For "A" version of I/O port expander
#define SLAVE2_ADDR  0x39	// For "A" version of I/O port expander 

#define MESSAGEBUF_SIZE       4

// LED and Button Ports
#define PORT_LED	PORTD
#define PORT_BUTTON	PORTD
#define DDR_LED   	DDRD
#define DDR_BUTTON  DDRD
#define PIN_BUTTON  PIND
#define P_LED_1		PD6
#define P_BUTTON	PD2

void blinkEm( uint8_t count);

void TWI_Act_On_Failure_In_Last_Transmission ( unsigned char TWIerrorMsg )
{
                    // A failure has occurred, use TWIerrorMsg to determine the nature of the failure
                    // and take appropriate actions.
                    // See header file for a list of possible failure messages.

	blinkEm(TWIerrorMsg);
}

//---------------------------------------------------------------------------
// Behavior: 
//		Blink LED at start.
//		Wait for button.
//		On button press, read Port Expanders and modify timer controls.
//		Flash code if there's an error.
//---------------------------------------------------------------------------

void main( void )
{
  unsigned char messageBuf[MESSAGEBUF_SIZE];
  unsigned char temp;
	uint8_t but1, but1a, oldBut;
	unsigned int cycleTime, onTime;
	
	/* Initialize Button - Pull up*/
	PORT_BUTTON |= _BV(P_BUTTON) ;
	oldBut = 0;	// button not pressed
	
	/* Initialize LED blinker  */
	DDR_LED |= _BV(P_LED_1);		      // enable output
	
	// Set up Timer/Counter 1 -- Setup is done below so things don't start until times are set.
	DDRB |= _BV(PB4);		      // enable output on port B, pin 4 - OC1B
    
    blinkEm(2);		// Blink as init signal

  USI_TWI_Master_Initialise();
  
  while(1){

	/* --------------------------------------------------------------
	** Read button. If it is changed, then do actions.
	**--------------------------------------------------------------*/
   
	but1 = ~PIN_BUTTON & _BV(P_BUTTON);	// look at buttons, invert
	if (but1 != oldBut)		
	{
		_delay_ms(100);		// debounce
		but1a = ~PIN_BUTTON & _BV(P_BUTTON);		// read again
		if (but1a == but1) 			// button has changed
		{
			oldBut = but1;
			if (oldBut > 0)		// Switch is pressed
			{
			// Read the I2C Port for Cycle Length
				messageBuf[0] = (SLAVE1_ADDR<<TWI_ADR_BITS) | (1<<TWI_READ_BIT); 
				temp = USI_TWI_Start_Read_Write( messageBuf, 2 );
				if (!temp)    // One of the operations failed.
				{             // Use TWI status information to detemine cause of failure.
						TWI_Act_On_Failure_In_Last_Transmission( USI_TWI_Get_State_Info( ) );  
				}
				else
				{
					cycleTime = messageBuf[1] * 98; //One Tenth Second increments
					// Read the I2C Port for On Time
					messageBuf[0] = (SLAVE2_ADDR<<TWI_ADR_BITS) | (1<<TWI_READ_BIT); 
					temp = USI_TWI_Start_Read_Write( messageBuf, 2 );
					if (!temp)    // One of the operations failed.
					{             // Use TWI status information to detemine cause of failure.
							TWI_Act_On_Failure_In_Last_Transmission( USI_TWI_Get_State_Info( ) );  
					}
					else
					{
						onTime = messageBuf[1] * 98;			//One Tenth Second increments
						OCR1A = cycleTime;		// Total Cycle Length
						OCR1B = onTime;		// Heater ON time
// Timer/Counter 1 configured for Fast PWM; OCR1A is TOP; Clear on Match, Set at TOP, 
//   divide clock by 1024
						TCCR1A = _BV(COM1B1) | _BV(WGM11) | _BV(WGM10);
						TCCR1B =  _BV(CS10) | _BV(CS12) | _BV(WGM13) | _BV(WGM12);	
					}
				}

			}
		}	
	}
  }

  return;
}

/*------------------------------------------------------------------------
**  blinkEm - function to blink LED for count passed in
**		Assumes 1MHz Clock Rate.
** ---------------------------------------------------------------------*/
void blinkEm( uint8_t count){
	uint8_t i;
	while (count > 0){
		PORT_LED |= _BV(P_LED_1); 
		for (i=0;i<5;i++)
		{
			_delay_ms(200);
		}
		PORT_LED &= ~_BV(P_LED_1); 
		for (i=0;i<5;i++)
		{
			_delay_ms(200);
		}
		count--;
	}
}
