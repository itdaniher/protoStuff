#include "WProgram.h"
void setup();
void loop();

#include "Wire/Wire.h"
#include "Wire/utility/twi.h"
#include "../PCA9635.h"
#include "../globals.h"

void setup ( void ) {
	Serial.begin(19200);
	Wire.begin();
	pinMode(13, 1);
	digitalWrite(13, 1);
}

void loop ( void ) {
	messageBuf = {MODE1|0b100<<5, 0b10000001, 0b00110100, MAX, MIN, MAX, MIN, MAX, MIN, MAX, MIN, MAX, MIN, MAX, MIN, MAX, MIN, MAX, MIN, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}; 
	Wire.beginTransmission(ALLCALL_addr);
	Wire.send(messageBuf, 25);
	Wire.endTransmission();
	digitalWrite(13, 0);
}
