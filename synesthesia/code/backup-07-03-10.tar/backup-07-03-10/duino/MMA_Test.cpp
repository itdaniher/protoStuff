#include "WProgram.h"
void setup();
void loop();

#include "Wire/Wire.h"
#include "Wire/utility/twi.h"
#include "../MMA7455l.h"
#include "../globals.h"

void setup ( void ) {
	Serial.begin(19200);
	Wire.begin();
	digitalWrite(13, 1);
}

void loop ( void ) {
	pinMode(13, 1);
	Wire.beginTransmission(MMA_ADDR);
	unsigned char messageBuf []={MMA_MCTL,MMA_MCTL_VALUE_ON};
	Wire.send(messageBuf,2);
	Wire.endTransmission();
	delay(30);
	Wire.beginTransmission(MMA_ADDR);
	Wire.send(MMA_XOUT8);
	Wire.endTransmission();
	Wire.requestFrom(MMA_ADDR, 3);
	Serial.print("\tX = ");
	Serial.print((char)Wire.receive(),DEC);
	Serial.print("\tY = ");
	Serial.print((char)Wire.receive(), DEC);
	Serial.print("\tZ = ");
	Serial.println((char)Wire.receive(), DEC);
	pinMode(13, 0);
	delay(50);
}
