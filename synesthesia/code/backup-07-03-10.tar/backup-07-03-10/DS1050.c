#include "USI_TWI_Master.h"
#include <avr/io.h>
#include <util/delay.h>
#include "globals.h"

void main(void){
	USI_TWI_Master_Initialise();
	messageBuf[0] = 0b01011100;
	temp = 0x00;
	for (;;) {
	temp++;
	messageBuf[1] = temp%0x1F;
	USI_TWI_Start_Read_Write(messageBuf, 2);
	_delay_ms(100);
	}
}
