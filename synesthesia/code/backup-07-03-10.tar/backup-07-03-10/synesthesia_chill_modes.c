//PB0 / SDA
//PB1 as input, low - sink current
//PB2 / SCL
//PB3 / ADC3 as input
//PB4 / PCINT4 as interrupt

#include "globals.h"
//include colorshift, MODE definitions, lots of random stuff
#include "PCA9635.h"
//include custom register definitions for the PCA9635
#include "MMA7455l.h"
//include custom register definitions for the MMA7455l
#include "USI_TWI_Master.h"
//I2C driver for the Attiny's USI hardware
/*	see http://www.instructables.com/id/I2C_Bus_for_ATtiny_and_ATmega/step3/I2C-Drivers/ for a really nice explaination of the various functions in USI_TWI_Master
 *	USI_TWI_Start_Read_Write: "So if 6 bytes are to be written, then the message size will be 8 (slave address + memory address + 6 bytes of data)."
 *	USI_TWI_Start_Random_Read: "The messageSize should be 2 plus the number of bytes to be read.
 *		If no errors occurred, the data will be in the buffer beginning at the second location."
 *	in short...
 * 	use USI_TWI_Start_Read_Write for single byte read/writes and multi-byte writes
 *	use USI_TWI_Start_Random_Read for multi-byte reads
 */

#include <util/delay.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/math.h>

void handleError( char errorMsg ){
//basic premise is to cause an externally visible indicator if i2c errors occur.
//this code toggles the output-enable pin at 5hz with a 50% duty cycle
	for (;;) {
		_delay_ms(100);
		PORTB = (1 << PB1);
		_delay_ms(100);
		PORTB = (0 << PB1);
	}
}

int map(long x, long in_min, long in_max, long out_min, long out_max)
{
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

void color_write(char LED, char r, char g, char b)
{
int index = 2 + (LED * 3);
    color_pass[index] = r;          //Red
    color_pass[index + 1] = g;      //Green
    color_pass[index + 2] = b;      //Blue
}

int color_map(int color_in, char LED)
{
    if (color_in < 85 ) {
        r = 255-3*color_in;
        g = 3*color_in;
        b = 0; }

    if ( index > 84 && index < 170 ) {
        r = 0;
        g = 255- 3 * (color_in-85);
        b = 3 * (color_in-85); }

    if ( index > 169 && index < 256 ) {
        r = 3 * (color_in-170);
        g = 0;
        b = 255-3 * (color_in-170); }
        
        color_write(LED, r, g, b);
}

ISR(PCINT0_vect){
	MODE_COUNT += 1;
	if ( MODE_COUNT > 0x05 ){
		MODE_COUNT = 0x00;
	} //handles a MODE_COUNT larger than 0x05 - we only have six mode options.
}

ISR(ADC_vect){
    colorshift = ADCH;
}

ISR(TIM0_OVF_vect){
	messageBuf[0] = (0x42<<TWI_ADR_BITS) | (1<<TWI_READ_BIT); 
//    TCMT0 = 127;
//upon overflow, set TCNT0 to 128, giving a trigger frequency of 8MHz/256/128 = 244.1Hz
	messageBuf[0] = (MMA7455l_addr<<TWI_ADR_BITS)|(1<<TWI_READ_BIT);
//accelerometer address is contained in variable MMA7455l_addr
	messageBuf[1] = XOUT8;
//starting register address is contained in variable XOUT8
	temp = USI_TWI_Start_Random_Read( messageBuf, 5 );
//read three bytes into messageBuf, where, barring errors, X = messageBuf[1], Y = messageBuf[2], and Z = messageBuf[3]
	if (!temp){
		handleError(USI_TWI_Get_State_Info( ));
	}
}

void MMA7455l_init(void){
	messageBuf[0] = (MMA7455l_addr<<TWI_ADR_BITS)|(0<<TWI_READ_BIT);
	messageBuf[1] = MCTL;
	messageBuf[2] = MCTL_VALUE;
	USI_TWI_Start_Read_Write(messageBuf, 3);
	messageBuf[0] = (MMA7455l_addr<<TWI_ADR_BITS)|(0<<TWI_READ_BIT);
	messageBuf[1] = CTL1;
	messageBuf[2] = CTL1_VALUE;
	USI_TWI_Start_Read_Write(messageBuf, 3);
	messageBuf[0] = (MMA7455l_addr<<TWI_ADR_BITS)|(0<<TWI_READ_BIT);
	messageBuf[1] = PW;
	messageBuf[2] = PW_VALUE;
	USI_TWI_Start_Read_Write(messageBuf, 3);
}
void PCA9635_init(void){
	char messageBuf[] = {0, 0, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
//set all 16 channels to max(duty cycle of very-close-to 100%)
	messageBuf[0] = (PCA9635_addr<<TWI_ADR_BITS)|(0<<TWI_READ_BIT);
	messageBuf[1] = PWM0 | 0b10100000;
//start at PWM0, set auto-increment to "individual brightness registers only," mask of 0b10100000
	USI_TWI_Start_Read_Write(messageBuf, 17);
}

int main( void ){
/* --BEGIN SETUP-- */
/*TWI/USI code*/
	USI_TWI_Master_Initialise();
/*digital pin code*/
	DDRB = (1 << DDB1);
	//PB1 as output
	PORTB = (0 << PB1);
	//PB1 as low(sink)
/*interrupt code*/
	GIMSK  |= (1<<PCIE); // enable PCINT interrupt in the general interrupt mask
	PCMSK |= (1<<PCINT4); //  tell pin change mask to listen to PB4/pin3
	sei(); // Enable all interrupts
/*adc code*/
	ADMUX = (0 << REFS1)|(0 << REFS0)|(1 << ADLAR);
	//use VCC as V_ref
	//ADLAR : left adjust result
	ADMUX += 3;
	//read PB3
	ADCSRA = (1 << ADEN)|(1 << ADSC)|(1 << ADATE)|(1 << ADIE);
	//ADEN : enable
	//ADSC : start conversion
	//ADATE : enable autotrigger
	//ADIE : enable ADC interrupt
	DIDR0 = (1 << ADC3D);
	//disable digital input on PB3 to save juice 
	ADCSRB = (1 << ADTS2);
	//set ADC autotrigger source to Timer/Counter0 overflow
/*timer code*/
	//timer @ 8MHz with 256x prescaler
	TIMSK = (1 << TOIE0);
	//TOIE0 : enable the overflow interrupt
	TCCR0B = (1 << CS02);
	//set a 256x prescaler on the clock
/*device-specific init code*/
	MMA7455l_init();
	PCA9635_init();
/* --END SETUP-- */

char g = 0x0F;
char accel_x = 0;
char accel_y = 0;
char accel_z = 0;
float accel_p = 0;
float theta = 0;
float accel_spin = 0;
float velocity = 0;
char vmap = 0;
char color_1 = 0;
char color_2 = 0;
char color_3 = 0;

char r = 0;
char g = 0;
char b = 0;
char LED = 0;

	for (;;) {
        accel_x = ;
        accel_y = ;
        accel_z = ;
        pot_read = ;
        
		switch( MODE_COUNT ){
			case M_DYNAMIC_ON:
                accel_p = hypot(accel_y, accel_z);
                theta = atan2(accel_p,accel_x);
                accel_spin = accel_x - g * cos(theta);
                velocity = sqrt(accel_spin);
                
                vmap = map(velocity,0,2.8,0,255);
                color_1 = (vmap + pot_read) % 0xFF;
                color_2 = (color_1 + 20) % 0xFF;
                color_3 = (color 1 + 40) % 0xFF;
                
                color_map(color1,0)
                color_map(color2,1)
                color_map(color3,2)
                color_map(color1,3)

			case M_STATIC_ON:
			case M_DYNAMIC_PULSE1:
			case M_STATIC_PULSE1:
			case M_DYNAMIC_PULSE2:
			case M_STATIC_PULSE2:
			default:break;
		};
	}
return 0;
}

