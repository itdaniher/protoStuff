//PB0 / SDA
//PB1 as input, low - sink current
//PB2 / SCL
//PB3 / ADC3 as input
//PB4 / PCINT4 as interrupt

#include <util/delay.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include "blink.c"

int main( void ){

	for (;;) {
	blink();
	}

return 0;
}

